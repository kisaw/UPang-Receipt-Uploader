<?php include 'session_admin.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php 
if (isset($_POST['addstudent']))

{

	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$studentNumber = $_POST['studentNumber'];
	$email = $_POST['email'];
	$contact = $_POST['contact'];
	$course = $_POST['course'];
	
	$firstsemester= 'First Periodic';
	$secondsemester='Second Periodic';
	$thirdsemester='Third Periodic';

$checkstudentnumber = mysqli_query($studentconnection,"SELECT * FROM studentaccount WHERE studentNumber ='$studentNumber'");
	if(mysqli_num_rows($checkstudentnumber)>0){
				echo "<script>alert('Student number was already exist');</script>";
				echo "<script>document.location='student.php';</script>";
				exit();
	}
	$query= "INSERT INTO studentaccount (firstName,lastName,studentNumber,email,contact,course,password) VALUES ('".strtoupper($firstName)."','".strtoupper($lastName)."','$studentNumber','$email','$contact','$course','".strtoupper($lastName)."')";
	$query_run = mysqli_query($studentconnection,$query);
	 if($query_run)
    {	
        echo "<script>alert('A student account was successfully added');</script>";
        echo "<script>document.location='student.php';</script>";
?>
			<!--ACTIVITY LOGS-->
			<?php 
			$admin=$_SESSION['userName'];
			$action='Added a student account [NAME: '.$firstName.' '.$lastName.' STUDENT NUMBER: '.$studentNumber.' COURSE:'.$course.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->

	<?php
       
    }
 	else
    {
         echo "<script>alert('upload not successful');</script>";
        echo "<script>document.location='student.php';</script>";
    }
}

 ?>