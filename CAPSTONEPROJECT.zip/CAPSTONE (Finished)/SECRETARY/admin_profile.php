<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT -->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- BOOTSTRAP -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>	
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="../CSS/style.css">
	<style type="text/css">
		.container{
	width: 100%;
	height: auto;
	background: lightgrey;
	padding: 40px;
	text-align: center;
	margin-top: 2%;
	border-radius: 2em;
	border-style: solid;
	border-color: green;

}

input{
	margin-bottom: 1em;
}
button{
	float: right;
}

.card{
	margin-top: 3em;
	margin-left: auto;
	margin-right: auto;
	text-align: center;
	border-radius: 2em;
	border-style: solid;
	border-color: green;
	height: auto;
	padding: 10px;
}

img.card-body{
	margin-left: auto;
	margin-right: auto;
}

img{
	border-radius: 50%;
}
	</style>

	<title>Profile</title>
</head>
<body>
<!--PHP Getting Name-->
	<?php
	$id=$_SESSION['secretaryUsername'];
	$adminquery="SELECT * FROM secretaryuseraccount WHERE userName='$id'";
	$adminquery_run = mysqli_query($adminconnection, $adminquery);
	?>
<!--ADMIN PROFILE PICTURE DISPLAY-->
	<?php
		if(mysqli_num_rows($adminquery_run)>0){
			while($row = mysqli_fetch_assoc($adminquery_run)){
		if($row['profilepicture']==""){
			$default ="<img src='adminprofilepicture/default.png' alt='default profile'";
			}
		else{
			$default ="<img src='adminprofilepicture/".$row['profilepicture']."' alt='default profile'";
			}
	?>
	<!-- SIDEBAR -->
	<section id="sidebar" class="hide">
		<a href="#" class="brand">
			<i class='bx bx-archive-out'></i>
			<span class="text"><span>UPANG<span class="subtitle"> RECEIPT UPLOADER</span></span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="index.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="student.php">
					<i class='bx bxs-user-circle'></i>
					<span class="text">Students</span>
				</a>
			</li>
		</ul>	
	</section>
	<!-- SIDEBAR -->

	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu'></i>
			<form action="#">
				<div class="form-input">
					<h3>Secretary Center</h3>
				</div>
			</form>
		
			</a>
			<div class="btn-group" role="group">
			    <button id="btnGroupDrop1" type="button" class="btn btn-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Welcome, <?php echo strtoupper($row['userName']);?></button>
		   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
			      <li><a class="dropdown-item" href="admin_profile.php">Profile</a></li>
			      <li><a class="dropdown-item" href="change_password.php">Change password</a></li>
						<li><a class="dropdown-item" href="logout_admin.php" onClick ="return confirm('Are you  sure you want to logout?');" style="color: red;">Logout</a></li>	      
			    </ul>
		  	</div>
			<a href="#" class="profile">
			<?php echo $default;?> 
			</a>
					
		</nav>
		<!-- NAVBAR -->

<?php 
}
	}
?>

		<!-- MAIN -->
		<main>

			 <!--PHP Getting Name-->
				<?php
				$id=$_SESSION['secretaryUsername'];
		$adminquery="SELECT * FROM secretaryuseraccount WHERE userName='$id'";
		$adminquery_run = mysqli_query($adminconnection, $adminquery);
	?>


 <!--ADMIN PROFILE DISPLAY-->
	<?php
		if(mysqli_num_rows($adminquery_run)>0){
			while($row = mysqli_fetch_assoc($adminquery_run))
		{
			if($row['profilepicture']==""){
					$default ="<img width='200' height='200' src='adminprofilepicture/default.png' alt='default profile'";
				}
				else{
					$default ="<img width='200' height='200' src='adminprofilepicture/".$row['profilepicture']."' alt='default profile'";
					}
	?>
	
	<div class="card" style="width:400px">
	  <?php  echo $default;?>
	  <div class="card-body">
		    <h4 class="card-title"><?php echo  $row['firstName'],' ', $row['lastName'];?></h4>
		    <p class="card-text"><?php echo  $row['email'];?></p>
		    <p class="card-text"><?php echo  $row['contact'];?></p>
		    <!-- BUTTON FOR UPDATING PROFILE -->
		    <button type="button" class="update btn btn-primary" data-bs-toggle="modal" data-bs-target="#adminprofileModal"  style="width:10em; margin: auto;">UPDATE PROFILE</button>
	  </div>
	</div>



	<!--MODAL FOR PROFILE PICTURE UPLOAD-->
<div class="modal fade" id="adminprofileModal" tabindex="-1" aria-labelledby="adminprofileModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="adminprofileModalLabel"> UPDATE PROFILE</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
			<form action="" method="POST" enctype="multipart/form-data">
				<label>Profile Picture</label>
					<input class="form-control" value="<?php echo $default;?>" type="file" name="file">
				<label>First Name</label>
					<input type="text" name="firstName" class="form-control" value="<?php echo  $row['firstName'];?>" placeholder="First Name" pattern="[A-Za-z ]{2,100}" title="invalid format. please insert more than 2 characters" required>
				<label>Last Name</label>
					<input type="text" name="lastName" class="form-control" value="<?php echo  $row['lastName'];?>" placeholder="Last Name" pattern="[A-Za-z ]{2,100}" title="invalid format. please insert more than 2 characters" required>
				<label>Email</label>
					<input type="text" name="email" class="form-control" value="<?php echo  $row['email'];?>" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="use the proper format example: characters@gmail.com">
				<label>Contact Number</label>
					<input type="text" name="contact" class="form-control" value="<?php echo  $row['contact'];?>" placeholder="Contact Number" pattern="[0-9]{11}" title="invalid number and use the proper format example: 09876543210" required>	
				<button type="submit" name="submit" class="btn btn-success">Submit</button>
			</form>	
      </div>
    </div>
  </div>
</div>

	<?php 
	}
		}

	?>
<!--POST METHOD FOR UPLOADING PROFILE PICTURE-->
<?php
	if(isset($_POST['submit'])){
		$id=$_SESSION['secretaryUsername'];
		$firstName = $_POST['firstName'];
		$lastName = $_POST['lastName'];
		$email = $_POST['email'];
		$contact = $_POST['contact'];
		if ($_FILES['file']['name']=='') {
			mysqli_query($adminconnection,"UPDATE secretaryuseraccount SET  firstName='$firstName', lastName='$lastName', email='$email', contact='$contact' WHERE userName='$id'");
				
				echo "<script>alert('Profile updated successfully');</script>";
       			 echo "<script>document.location='admin_profile.php';</script>";
       			 exit();
		}
		else{
		move_uploaded_file($_FILES['file']['tmp_name'],"adminprofilepicture/".$_FILES['file']['name']);
		mysqli_query($adminconnection,"UPDATE secretaryuseraccount SET profilepicture ='".$_FILES['file']['name']."', firstName='$firstName', lastName='$lastName', email='$email', contact='$contact' WHERE userName='$id'");
				
				echo "<script>alert('Profile updated successfully');</script>";
       			 echo "<script>document.location='admin_profile.php';</script>";
       			 exit();
	}
	}
?>


		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>