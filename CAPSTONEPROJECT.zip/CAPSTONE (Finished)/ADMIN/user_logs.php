<?php include '../DATABASE/db_admin_connection.php'?>
<?php include_once 'session_admin.php'?>
<?php 
if(isset($_POST['delete_record']))
{
	$password=$_POST['password'];
	$admin=$_SESSION['userName'];

	$checkpassword= mysqli_query($adminconnection,"SELECT * FROM adminuseraccount WHERE userName='$admin' AND password = '$password'");
	if (mysqli_num_rows($checkpassword)>0) {
	mysqli_query($adminconnection,"DELETE FROM activitylog");
?>
		 <!--ACTIVITY LOGS-->
		<?php 
		$action='Deleted all user log records';
			$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
			$query_run = mysqli_query($adminconnection,$query);
		?>
		<!--ACTIVITY LOGS-->
<?php	
		echo "<script>alert('User logs deleted successfully');</script>";
        echo "<script>document.location='user_logs.php';</script>";
        exit();

}
	else{
		echo "<script>alert('Your password does not match');</script>";
        echo "<script>document.location='user_logs.php';</script>";
        exit();
	}
}

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>	
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
	<!--SCRIPT FOR SEARCH BAR-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS IN PAGINATION-->
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
	<!-- My CSS -->
	<link rel="stylesheet" href="../CSS/style.css">

	<title>User Logs</title>
</head>
<body>

<!--PHP Getting Name-->
	<?php
	$id=$_SESSION['userName'];
	$adminquery="SELECT * FROM adminuseraccount WHERE userName='$id'";
	$adminquery_run = mysqli_query($adminconnection, $adminquery);
	?>
<!--ADMIN PROFILE PICTURE DISPLAY-->
	<?php
		if(mysqli_num_rows($adminquery_run)>0){
			while($row = mysqli_fetch_assoc($adminquery_run)){
		if($row['profilepicture']==""){
			$default ="<img src='adminprofilepicture/default.png' alt='default profile'";
			}
		else{
			$default ="<img src='adminprofilepicture/".$row['profilepicture']."' alt='default profile'";
			}
	?>

	<!-- SIDEBAR -->
	<section id="sidebar" class="hide">
		<a href="#" class="brand">
			<i class='bx bx-archive-out'></i>
			<span class="text"><span>UPANG<span class="subtitle"> RECEIPT UPLOADER</span></span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="index.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="student.php">
					<i class='bx bxs-user-circle'></i>
					<span class="text">Students</span>
				</a>
			</li>
			<li>
				<a href="request.php">
					<i class='bx bxs-help-circle' ></i>
					<span class="text">Request</span>
				</a>
			</li>
			<li>
				<a href="user_account.php">
					<i class='bx bxs-group'></i>
					<span class="text">User Accounts</span>
				</a>
			</li>
			<li class="active">
				<a href="#">
					<i class='bx bxs-notepad'></i>
					<span class="text">User logs</span>
				</a>
			</li>
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>			
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<form action="#">
				<div class="form-input">
					<h3>Administration Center</h3>
				</div>
			</form>
<!--NOTIFICATION-->
			<div class="btn-group" role="group">
			   <button id="btnGroupDrop" type="button" class="btn dropdown-toggle " data-bs-toggle="dropdown" aria-expanded="false" style="background-color:transparent"><i class='bx bxs-bell'>
			    	
			<?php
				$requestquery="SELECT * FROM admin_notification WHERE status='0'";
				$requestquery_run = mysqli_query($adminconnection, $requestquery);
				$totalrequest = mysqli_num_rows($requestquery_run);
				if ($totalrequest>0) {
					echo "<span class='num'>$totalrequest</span>";
				}
				?>
			</i></button>
		   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop">
		   	 	<?php 
		   	 	$requestquery1 =mysqli_query($adminconnection,"SELECT * FROM admin_notification WHERE status='0'");
				if (mysqli_num_rows($requestquery1)>0) {
					while($result =mysqli_fetch_assoc($requestquery1)){
						echo '<li><a class="dropdown-item" href="request.php?notif='.$result['id'].'"><span style="font-weight:bold;">'.$result['studentNumber'].' '.$result['fullName'].'</span><br> '.$result['description'].' '.$result['periodic'].' form</a></li>';
						echo '<div class="dropdown-divider"></div>';
					}
				}
				else{
					echo '<li><a class="dropdown-item text-danger" href="">No notification</a></li>';
				}
				 ?>	
			    </ul>
		  	</div>
<!--NOTIFICATION-->

			<div class="btn-group" role="group">
			    <button id="btnGroupDrop1" type="button" class="btn btn-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Welcome, <?php echo strtoupper($row['userName']);?></button>
		   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
			      <li><a class="dropdown-item" href="admin_profile.php">Profile</a></li>
			      <li><a class="dropdown-item" href="change_password.php">Change password</a></li>
			      <li><a class="dropdown-item" href="logout_admin.php" onClick ="return confirm('Are you  sure you want to logout?');" style="color: red;">Logout</a></li>
			    </ul>
			    </ul>
		  	</div>
			<a href="#" class="profile">
				<?php echo $default;?>
			</a>
		</nav>
		<!-- NAVBAR -->

<?php 
}
	}
?>	


<!-- MAIN -->
<main>
	<div class="head-title" style="margin-bottom: 2em;">
		<div class="left">
			<h1>Users log Section</h1>
		</div>
	</div>			 	
<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal" style="margin: 1em 0;"><i class='bx bxs-trash'></i>
  Delete All records
</button> -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST" action="">
        	<h5>Enter your password</h5>
        	<input type="password" name="password" class="form-control" placeholder="password" required>
      </div>
      <div class="modal-footer">
        <button type="text" name="delete_record" class="btn btn-primary" onclick="return confirm('are you sure you want to delete all user logs?');">Comfirm</button>
        </form>
      </div>
    </div>
  </div>
</div>

	<div class="table-responsive table1">
		<table class="table table-hover table-bordered" id="datatable" cellspacing="0">
		<thead>
			<tr style="background-color: #647842; color: white;">
				<th>Admin</th>
				<th>Action</th>	
				<th>Date</th>	
			</tr>
		</thead>
		<tbody id="myTable">
	<?php 

		
		$query = "SELECT * FROM activitylog";
		$query_run = mysqli_query($adminconnection, $query);
	?>
			<?php
				if (mysqli_num_rows($query_run) >0) {
					while($row = mysqli_fetch_assoc($query_run))
					{	
				?>

				<tr>
					<td><?php echo $row['admin'];?></td>
					<td><?php echo $row['action']; ?></td>
					<td><?php echo $row['date'];?></td>
				</tr>

					<?php
					}
			}	
					else{
						?>
						<tr>
							<td colspan="3">No record</td>
						</tr>
					<?php
				}

				?>

		</tbody>
	</table>
</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
<!-- My SCRIPT IN PAGINATION AND SEARCH-->
	<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
	<script>
		$(document).ready(function() {
    $('#datatable').DataTable();
} );
	</script>
<!-- My SCRIPT IN PAGINATION AND SEARCH-->		
</body>
</html>