<?php


/*$host = "localhost";  Host name 
$user= "root";  User 
$password = "";  Password 
$dbname = "adminpanel";  Database name */

$studentconnection = mysqli_connect("localhost","root","","dbstudents"); //connecting to the database
// Check connection
if (!$studentconnection) {
 die("Connection failed: " . mysqli_connect_error()); //terminates the execution
}

