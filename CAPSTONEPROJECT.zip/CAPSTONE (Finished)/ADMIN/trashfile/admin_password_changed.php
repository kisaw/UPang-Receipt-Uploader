<?php require_once "controller_admin_data.php"; ?>
<?php 
$email = $_SESSION['email'];
if($email == false){
  header('Location: admin_login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
     <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,700;1,300&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../CSS/login.css">
</head>
<body>
    <div class="hero-img"></div>
    <div class="container">
        
            <div class="title">
                <h1>Online Receipt Uploader for PHINMA-UNIVERSITY OF PANGASINAN</h1>
                <h2>New<span>Password</span></h2>
            </div>  

            <?php 
            if(isset($_SESSION['info'])){
                ?>
                <div class="alert alert-success text-center">
                <?php echo $_SESSION['info']; ?>
                </div>
                <?php
            }
            ?>
                <form action="admin_login.php" method="POST">
                         
            <div class="button">
                 <input type="submit" name="login-now" value="Login Now" class="btn btn-secondary">
            </div>
        
        </form>
    </div>

</body>
</html>