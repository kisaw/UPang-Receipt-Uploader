<?php 
session_start();
if(!isset($_SESSION['userName'])){
	header('Location: admin_login.php');
}

?>