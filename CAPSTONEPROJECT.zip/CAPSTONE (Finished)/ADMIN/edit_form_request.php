<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php 
	if(isset($_POST['updateform'])){
		$id=$_GET['editform'];

		$firstname= $_POST['firstname'];
		$lastname= $_POST['lastname'];
		$student_id= $_POST['student_id'];
		$email= $_POST['email'];
		$contact= $_POST['contact'];
		$amount= $_POST['amount'];

		
		$sql= mysqli_query($adminconnection, "UPDATE student_form SET firstname='$firstname', lastname='$lastname', student_id='$student_id', email='$email', contact='$contact', amount='$amount' WHERE id='$id'");

		if($sql){
			echo "<script>alert('A form was updated successfully')</script>";
			echo "<script>document.location='request.php';</script>";
			?>
			 <!--ACTIVITY LOGS-->
			<?php 
			$studentquery = "SELECT * FROM student_form WHERE id='$id'";
			$studentquery_run = mysqli_query($adminconnection, $studentquery);
			$row = mysqli_fetch_assoc($studentquery_run);
			$admin=$_SESSION['userName'];
			$firstname= $row['firstname'];
			$lastname= $row['lastname'];
			$student_id= $row['student_id'];
			$periodic= $row['semester'];

			$action='Edited a form request [NAME: '.$firstname.' '.$lastname.' STUDENT NUMBER: '.$student_id.' PERIODIC: '.$periodic.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->
			<?php
		}
		else{
			echo "<script>alert('Somthing went wrong!')</script>";
			echo "<script>document.location='edit_form_request.php';</script>";
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- BOOTSTRAP -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>

	<title>Edit Student Account</title>
	<!-- My CSS -->
	<style type="text/css">
.container{
 margin-top: 3rem;
 text-align: center;
 width: 50%;
}
h1{
	margin-bottom: 1em;
}
.form-control{
	margin-bottom: 1em;
}	

label{
	float: left;
	font-weight: bold;
}
div .button{
	text-align: right;
	display: block;
}

a img{
 margin-left: 1em;
 float: left;
}
</style>

</head>
<body>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>Edit Student Account</h1>
			</div>
		</div>

		<form method="POST">
			<?php 
				$id= $_GET['editform'];
				$sql= mysqli_query($adminconnection, "SELECT * FROM student_form WHERE id ='$id'");
					while ($row=mysqli_fetch_assoc($sql)){
			?>

			<div class="row">
				<div class="col-md-6">
					<label>First Name</label>
					<input type="text" name="firstname" value="<?php echo $row['firstname'];?>" class="form-control" placeholder="First Name" required>
				</div>	
				<div class="col-md-6">
					<label>Last Name</label>
					<input type="text" name="lastname" value="<?php echo $row['lastname'];?>" class="form-control" placeholder="Last Name" required>
				</div>	
			</div>

			<div class="row">
				<div class="col-md-12">
				<label>Student Number</label>
				<input type="text" name="student_id" value="<?php echo $row['student_id'];?>" class="form-control" placeholder="Student Number" readonly>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12">
				<label>Email</label>
				<input type="text" name="email" value="<?php echo $row['email'];?>" class="form-control" placeholder="Email" required>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
				<label>Contact Number</label>
				<input type="text" name="contact" value="<?php echo $row['contact'];?>" class="form-control" placeholder="Contact" required>
				</div>

			<div class="row">
				<div class="col-md-12">
				<label>Amount</label>
				<input type="text" name="amount" value="<?php echo $row['amount'];?>" class="form-control" placeholder="Contact" required>
				</div>

			<div class="row">
				<div class="col-md-12">
				<label>Uploaded file</label>
				<a href="../upload/<?php echo $row['image'];?>"><?php echo '<img src="../upload/'.$row['image'].'" width="100px" height="100px">'?></a>
				</div>	
			</div>	

			<?php
				 }
			 ?>

			
			<div class="button">
			<a href="request.php" type="button" class="btn btn-secondary">BACK</a>
			<button type="text" name="updateform" class="btn btn-primary" onClick ="return confirm('Do you really want to update this record?');">UPDATE</button>
			</div>
		</form>
	</div>

</body>
</html>