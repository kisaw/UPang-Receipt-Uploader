<?php
include'../DATABASE/db_admin_connection.php';
include_once 'session_admin.php';


if(isset($_GET['delete']))
{
	$id=$_GET['delete'];
	 ?>
			<!--ACTIVITY LOGS-->
			<?php 
			$studentquery = "SELECT * FROM student_form WHERE id='$id'";
			$studentquery_run = mysqli_query($adminconnection, $studentquery);
			$row = mysqli_fetch_assoc($studentquery_run);
			$admin=$_SESSION['userName'];
			$firstname= $row['firstname'];
			$lastname= $row['lastname'];
			$student_id= $row['student_id'];
			$periodic= $row['periodic'];

			$action='Delete a stundent form [NAME: '.$firstname.' '.$lastname.' STUDENT NUMBER: '.$student_id.' PERIODIC: '.$periodic.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->
		
	<?php	
//STUDENT NOTIFICATION
		$studentnotifquery = "SELECT * FROM student_form WHERE id='$id'";
			$studentnotifquery_run = mysqli_query($adminconnection, $studentnotifquery);
			$list = mysqli_fetch_assoc($studentnotifquery_run);
			$studentNumber= $list['student_id'];
			$feetype= $list['periodic'];
			$description= 'Deleted';
		mysqli_query($adminconnection,"INSERT INTO student_notification (studentNumber,periodic,description) VALUES('$studentNumber','$feetype','$description')");
//STUDENT NOTIFICATION

		mysqli_query($adminconnection,"DELETE FROM student_form WHERE id='$id'");
		echo "<script>alert('RECORD DELETED!');</script>";
        echo "<script>document.location='student.php';</script>";
          
}

 ?>