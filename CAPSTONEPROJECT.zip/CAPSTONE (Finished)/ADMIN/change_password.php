<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- BOOTSTRAP -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>	
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="../CSS/style.css">
	<style type="text/css">
		.container{
	width: 100%;
	height: auto;
	padding: 40px;
	text-align: center;
	margin-top: 2%;
	border-radius: 2em;
	border-style: solid;
	border-color: green;
}

input{
	margin-bottom: 1em;
}

.form-control{
	
}

button{
	float: right;
}

label{
	float: left;
}
img{
	border-radius: 50%;
}

	</style>

	<title>Dashboard</title>
</head>
<body>
<!--PHP Getting Name-->
	<?php
	$id=$_SESSION['userName'];
	$adminquery="SELECT * FROM adminuseraccount WHERE userName='$id'";
	$adminquery_run = mysqli_query($adminconnection, $adminquery);
	?>
<!--ADMIN PROFILE PICTURE DISPLAY-->
	<?php
		if(mysqli_num_rows($adminquery_run)>0){
			while($row = mysqli_fetch_assoc($adminquery_run)){
		if($row['profilepicture']==""){
			$default ="<img src='adminprofilepicture/default.png' alt='default profile'";
			}
		else{
			$default ="<img src='adminprofilepicture/".$row['profilepicture']."' alt='default profile'";
			}
	?>
	<!-- SIDEBAR -->
	<section id="sidebar" class="hide">
		<a href="#" class="brand">
			<i class='bx bx-archive-out'></i>
			<span class="text"><span>UPANG<span class="subtitle"> RECEIPT UPLOADER</span></span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="index.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="student.php">
					<i class='bx bxs-user-circle'></i>
					<span class="text">Students</span>
				</a>
			</li>
			<li>
				<a href="request.php">
					<i class='bx bxs-help-circle' ></i>
					<span class="text">Request</span>
				</a>
			</li>
			<li>
				<a href="user_account.php">
					<i class='bx bxs-group'></i>
					<span class="text">User Accounts</span>
				</a>
			</li>
			<li>
				<a href="user_logs.php">
					<i class='bx bxs-notepad'></i>
					<span class="text">User logs</span>
				</a>
			</li>
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>			
		</ul>
	</section>
	<!-- SIDEBAR -->

	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu'></i>
			<form action="#">
				<div class="form-input">
					<h3>Administration Center</h3>
				</div>
			</form>

<!--NOTIFICATION-->
			<div class="btn-group" role="group">
			   <button id="btnGroupDrop" type="button" class="btn dropdown-toggle " data-bs-toggle="dropdown" aria-expanded="false" style="background-color:transparent"><i class='bx bxs-bell'>
			    	
			<?php
				$requestquery="SELECT * FROM admin_notification WHERE status='0'";
				$requestquery_run = mysqli_query($adminconnection, $requestquery);
				$totalrequest = mysqli_num_rows($requestquery_run);
				if ($totalrequest>0) {
					echo "<span class='num'>$totalrequest</span>";
				}
				?>
			</i></button>
		   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop">
		   	 	<?php 
		   	 	$requestquery1 =mysqli_query($adminconnection,"SELECT * FROM admin_notification WHERE status='0'");
				if (mysqli_num_rows($requestquery1)>0) {
					while($result =mysqli_fetch_assoc($requestquery1)){
						echo '<li><a class="dropdown-item" href="request.php?notif='.$result['id'].'"><span style="font-weight:bold;">'.$result['studentNumber'].' '.$result['fullName'].'</span><br> '.$result['description'].' '.$result['periodic'].' form</a></li>';
						echo '<div class="dropdown-divider"></div>';
					}
				}
				else{
					echo '<li><a class="dropdown-item text-danger" href="">No notification</a></li>';
				}
				 ?>	
			    </ul>
		  	</div>
<!--NOTIFICATION-->

			<div class="btn-group" role="group">
			    <button id="btnGroupDrop1" type="button" class="btn btn-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Welcome, <?php echo strtoupper($row['userName']);?></button>
		   	 	<ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
			      <li><a class="dropdown-item" href="admin_profile.php">Profile</a></li>
			      <li><a class="dropdown-item" href="change_password.php">Change password</a></li>
			      <li><a class="dropdown-item" href="logout_admin.php" onClick ="return confirm('Are you  sure you want to logout?');" style="color: red;">Logout</a></li>	
			    </ul>
		  	</div>
			<a href="#" class="profile">
			<?php echo $default;?> 
			</a>
					
		</nav>
		<!-- NAVBAR -->

<?php 
}
	}
?>

		<!-- MAIN -->
		<main>
<div class="container">
<h1>Change Password</h1>

<!--POST METHOD FOR CHANGING PASSWORD-->
<?php
	if(isset($_POST['change_password'])){
		$id=$_SESSION['userName'];
		$currentpassword = $_POST['currentpassword'];
		$newpassword = $_POST['newpassword'];
		$renewpassword = $_POST['renewpassword'];
		
		$checkcurrentpassword= "SELECT * FROM adminuseraccount WHERE userName='$id' AND password='$currentpassword'";
		$checkcurrentpassword_run = mysqli_query($adminconnection,$checkcurrentpassword);

		if (mysqli_num_rows($checkcurrentpassword_run)==0){
			echo "<div class='alert alert-danger' role='alert'>
  						Please check your current password</div>";        
		}
		else{
			if ($newpassword!=$renewpassword) {
				echo "<div class='alert alert-danger' role='alert'>
  						new password does not match</div>";        
			}
			if ($newpassword==$renewpassword){
				mysqli_query($adminconnection,"UPDATE adminuseraccount SET password ='$newpassword' WHERE userName='$id'");
				echo "<div class='alert alert-success' role='alert'>
  						Change Password successful</div>";  
			}
		}
}
?>
<!--POST METHOD FOR CHANGING PASSWORD-->

<form method="POST">
<div class="field">
	<label>Current password</label>
			<input type="password" class="form-control" name="currentpassword" placeholder="Enter your current Password">
		</div>

<div class="field">
	<label>Enter your new password</label>
			<input type="password" class="form-control" name="newpassword" placeholder="Enter your new Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
		</div>

<div class="field">
	<label>Confirm your new password</label>
			<input type="password" class="form-control" name="renewpassword" placeholder="Confirm your new Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
		</div>			
	
<button type="submit" name="change_password" class="btn btn-success">Change</button>
</form>
</div>





		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>