-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2022 at 04:29 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adminpanel`
--

-- --------------------------------------------------------

--
-- Table structure for table `activitylog`
--

CREATE TABLE `activitylog` (
  `id` int(11) NOT NULL,
  `admin` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `action` varchar(200) NOT NULL,
  `schoolyear` varchar(50) NOT NULL DEFAULT '2021-2022',
  `semester` varchar(50) NOT NULL DEFAULT 'second semester'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activitylog`
--

INSERT INTO `activitylog` (`id`, `admin`, `date`, `action`, `schoolyear`, `semester`) VALUES
(183, 'admin', '2022-05-27 05:18:39', 'Added a School Year [SCHOOL YEAR: 2021-2022 SEMESTER: first semester]', '2021-2022', 'second semester'),
(184, 'admin', '2022-05-27 05:19:12', 'Applied a School Year [SCHOOL YEAR: 2021-2022 SEMESTER: first semester]', '2021-2022', 'first semester'),
(185, 'admin', '2022-05-27 05:19:18', 'Added a School Year [SCHOOL YEAR: 2021-2022 SEMESTER: second semester]', '2021-2022', 'first semester'),
(186, 'admin', '2022-05-27 05:19:22', 'Applied a School Year [SCHOOL YEAR: 2021-2022 SEMESTER: second semester]', '2021-2022', 'second semester'),
(187, 'admin', '2022-05-27 05:22:43', 'Added a student account [NAME: Joshua Quisao STUDENT NUMBER: 03-1617-03347 COURSE:Bachelor of Science in Information Technology]', '2021-2022', 'second semester'),
(188, 'admin', '2022-05-27 06:16:09', 'Verified a student form [NAME: JOSHUA QUISAO STUDENT NUMBER: 03-1617-03347 PERIODIC: First Periodic]', '2021-2022', 'second semester'),
(189, 'admin', '2022-05-27 06:31:06', 'Verified a student form [NAME: JOSHUA QUISAO STUDENT NUMBER: 03-1617-03347 PERIODIC: Second Periodic]', '2021-2022', 'second semester'),
(190, 'admin', '2022-05-27 06:32:03', 'Verified a student form [NAME: JOSHUA QUISAO STUDENT NUMBER: 03-1617-03347 PERIODIC: Third Periodic]', '2021-2022', 'second semester'),
(191, 'admin', '2022-05-27 06:32:51', 'Added a student account [NAME: John Doe STUDENT NUMBER: 03-1234-56789 COURSE:Bachelor of Science in Information Technology]', '2021-2022', 'second semester'),
(192, 'admin', '2022-05-27 06:48:53', 'Added a user account [NAME: Jane Doe USERNAME: secretary]', '2021-2022', 'second semester'),
(193, 'admin', '2022-05-27 07:06:38', 'Edit a user account [NAME:   STUDENT NUMBER:  COURSE: ]', '2021-2022', 'second semester'),
(194, 'admin', '2022-05-27 07:08:39', 'Edit a user account [NAME:   STUDENT NUMBER:  COURSE: ]', '2021-2022', 'second semester'),
(195, 'admin', '2022-05-27 07:08:51', 'Edit a user account [NAME:   STUDENT NUMBER:  COURSE: ]', '2021-2022', 'second semester'),
(196, 'admin', '2022-05-27 07:11:15', 'Delete a user account [NAME:   Username: ]', '2021-2022', 'second semester'),
(197, 'admin', '2022-05-27 07:12:34', 'Added a user account [NAME: fasda fsadsa USERNAME: f]', '2021-2022', 'second semester'),
(198, 'admin', '2022-05-27 07:12:45', 'Edit a user account [NAME:   STUDENT NUMBER:  COURSE: ]', '2021-2022', 'second semester'),
(199, 'admin', '2022-05-27 07:12:48', 'Delete a user account [NAME:   Username: ]', '2021-2022', 'second semester'),
(200, 'admin', '2022-05-27 07:14:13', 'Added a user account [NAME: aasd asdas USERNAME: asda]', '2021-2022', 'second semester'),
(201, 'admin', '2022-05-27 07:14:20', 'Delete a user account [NAME: aasd asdas Username: ]', '2021-2022', 'second semester'),
(202, 'admin', '2022-05-27 15:01:14', 'Verified a student form [NAME: JOHN DOE STUDENT NUMBER: 03-1234-56789 PERIODIC: First Periodic]', '2021-2022', 'second semester'),
(203, 'admin', '2022-05-27 15:54:00', 'Verified a student form [NAME: JOHN DOE STUDENT NUMBER: 03-1234-56789 PERIODIC: First Periodic]', '2021-2022', 'second semester'),
(204, 'admin', '2022-05-27 15:55:22', 'Verified a student form [NAME: JOHN DOE STUDENT NUMBER: 03-1234-56789 PERIODIC: First Periodic]', '2021-2022', 'second semester'),
(205, 'admin', '2022-05-27 16:50:29', 'Verified a student form [NAME: JOHN DOE STUDENT NUMBER: 03-1234-56789 PERIODIC: Second Periodic]', '2021-2022', 'second semester'),
(206, 'admin', '2022-05-28 05:11:34', 'Verified a student form [NAME: JOHN DOE STUDENT NUMBER: 03-1234-56789 PERIODIC: Second Periodic]', '2021-2022', 'second semester'),
(207, 'admin', '2022-05-28 05:49:14', 'Verified a student form [NAME: JOHN DOE STUDENT NUMBER: 03-1234-56789 PERIODIC: Third Periodic]', '2021-2022', 'second semester');

-- --------------------------------------------------------

--
-- Table structure for table `adminuseraccount`
--

CREATE TABLE `adminuseraccount` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `code` varchar(10) NOT NULL,
  `profilepicture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminuseraccount`
--

INSERT INTO `adminuseraccount` (`id`, `firstName`, `lastName`, `userName`, `password`, `email`, `contact`, `code`, `profilepicture`) VALUES
(53, 'System', 'Default', 'admin', 'admin', 'admin@gmail.com', '09458218422', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notification`
--

CREATE TABLE `admin_notification` (
  `id` int(11) NOT NULL,
  `studentNumber` varchar(20) NOT NULL,
  `fullName` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL DEFAULT 'Uploaded a ',
  `periodic` varchar(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_notification`
--

INSERT INTO `admin_notification` (`id`, `studentNumber`, `fullName`, `description`, `periodic`, `date`, `status`) VALUES
(43, '03-1617-03347', 'JOSHUA QUISAO', 'Uploaded a ', 'First Periodic', '2022-05-27 05:46:48', '1'),
(44, '03-1617-03347', 'JOSHUA QUISAO', 'Uploaded a ', 'Second Periodic', '2022-05-27 05:53:46', '1'),
(45, '03-1617-03347', 'JOSHUA QUISAO', 'Uploaded a ', 'Third Periodic', '2022-05-27 14:52:05', '1'),
(46, '03-1234-56789', 'JOHN DOE', 'Uploaded a ', 'First Periodic', '2022-05-27 15:52:43', '1'),
(47, '03-1234-56789', 'JOHN DOE', 'Uploaded a ', 'Second Periodic', '2022-05-28 01:05:55', '1'),
(48, '03-1234-56789', 'JOHN DOE', 'Uploaded a ', 'Second Periodic', '2022-05-28 05:17:37', '1'),
(49, '03-1234-56789', 'JOHN DOE', 'Uploaded a ', 'Second Periodic', '2022-05-28 05:17:40', '1'),
(50, '03-1234-56789', 'JOHN DOE', 'Uploaded a ', 'Second Periodic', '2022-05-28 05:17:41', '1'),
(51, '03-1234-56789', 'JOHN DOE', 'Uploaded a ', 'First Periodic', '2022-05-28 05:17:41', '1'),
(52, '03-1234-56789', 'JOHN DOE', 'Uploaded a ', 'Second Periodic', '2022-05-28 05:17:42', '1'),
(53, '03-1234-56789', 'JOHN DOE', 'Uploaded a ', 'Second Periodic', '2022-05-28 05:17:43', '1'),
(54, '03-1234-56789', 'JOHN DOE', 'Uploaded a ', 'Third Periodic', '2022-05-29 02:49:51', '1');

-- --------------------------------------------------------

--
-- Table structure for table `paymenthistory`
--

CREATE TABLE `paymenthistory` (
  `studentNumber` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `issuedBy` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `schoolyear_and_semester`
--

CREATE TABLE `schoolyear_and_semester` (
  `sy_id` int(11) NOT NULL,
  `year` varchar(20) NOT NULL,
  `sem` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'new'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schoolyear_and_semester`
--

INSERT INTO `schoolyear_and_semester` (`sy_id`, `year`, `sem`, `status`) VALUES
(14, '2021-2022', 'first semester', 'old'),
(15, '2021-2022', 'second semester', 'current');

-- --------------------------------------------------------

--
-- Table structure for table `secretaryuseraccount`
--

CREATE TABLE `secretaryuseraccount` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `userName` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `code` varchar(10) NOT NULL,
  `profilepicture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `secretaryuseraccount`
--

INSERT INTO `secretaryuseraccount` (`id`, `firstName`, `lastName`, `userName`, `password`, `email`, `contact`, `code`, `profilepicture`) VALUES
(1, 'Jane', 'Doe', 'secretary', 'Doe', 'janedoe@gmail.com', '09123456782', '', 'team3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `student_form`
--

CREATE TABLE `student_form` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `periodic` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `amount` double NOT NULL,
  `image` varchar(1000) NOT NULL,
  `schoolyear` varchar(50) NOT NULL DEFAULT '2021-2022',
  `semester` varchar(50) NOT NULL DEFAULT 'second semester',
  `approval` varchar(100) NOT NULL,
  `issuedBy` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_form`
--

INSERT INTO `student_form` (`id`, `firstname`, `lastname`, `student_id`, `email`, `contact`, `periodic`, `date`, `amount`, `image`, `schoolyear`, `semester`, `approval`, `issuedBy`) VALUES
(179, 'JOSHUA', 'QUISAO', '03-1617-03347', 'joshua@gmail.com', '09493816423', 'First Periodic', '2022-05-27 06:16:09', 3723, '249201351_346970780517365_5769542490354762777_n.jpg', '2021-2022', 'second semester', 'approved', 'System Default'),
(180, 'JOSHUA', 'QUISAO', '03-1617-03347', 'joshua@gmail.com', '09493816423', 'Second Periodic', '2022-05-27 06:31:06', 4700, 'sample receipt.jpg', '2021-2022', 'second semester', 'approved', 'System Default'),
(181, 'JOSHUA', 'QUISAO', '03-1617-03347', 'joshua@gmail.com', '09493816423', 'Third Periodic', '2022-05-27 06:32:03', 3723, 'bg.jpg', '2021-2022', 'second semester', 'approved', 'System Default'),
(182, 'JOHN', 'DOE', '03-1234-56789', 'john@gmail.com', '09123456789', 'First Periodic', '2022-05-27 15:01:14', 3723, '249201351_346970780517365_5769542490354762777_n.jpg', '2021-2022', 'second semester', 'semi-approved', 'System Default'),
(187, 'JOHN', 'DOE', '03-1234-56789', 'john@gmail.com', '09123456789', 'First Periodic', '2022-05-27 15:55:22', 1000, '249201351_346970780517365_5769542490354762777_n.jpg', '2021-2022', 'second semester', 'approved', 'System Default'),
(188, 'JOHN', 'DOE', '03-1234-56789', 'john@gmail.com', '09123456789', 'Second Periodic', '2022-05-27 16:50:29', 2000, 'bg.jpg', '2021-2022', 'second semester', 'semi-approved', 'System Default'),
(189, 'JOHN', 'DOE', '03-1234-56789', 'john@gmail.com', '09123456789', 'Second Periodic', '2022-05-28 05:11:34', 1000, 'bg.png', '2021-2022', 'second semester', 'approved', 'System Default'),
(190, 'JOHN', 'DOE', '03-1234-56789', 'john@gmail.com', '09123456789', 'Third Periodic', '2022-05-28 05:49:14', 3000, 'sample receipt.jpg', '2021-2022', 'second semester', 'semi-approved', 'System Default');

-- --------------------------------------------------------

--
-- Table structure for table `student_notification`
--

CREATE TABLE `student_notification` (
  `id` int(11) NOT NULL,
  `studentNumber` varchar(50) NOT NULL,
  `periodic` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `admin` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_notification`
--

INSERT INTO `student_notification` (`id`, `studentNumber`, `periodic`, `description`, `admin`, `date`, `status`) VALUES
(45, '03-1617-03347', 'First Periodic', 'Verified', 'System Default', '2022-05-27 06:17:18', 1),
(46, '03-1617-03347', 'Second Periodic', 'Verified', 'System Default', '2022-05-27 15:49:57', 1),
(47, '03-1617-03347', 'Third Periodic', 'Verified', 'System Default', '2022-05-27 06:32:03', 0),
(48, '03-1234-56789', 'First Periodic', 'Verified', 'System Default', '2022-05-27 15:45:29', 1),
(49, '03-1234-56789', 'First Periodic', 'Verified', 'System Default', '2022-05-28 05:27:55', 1),
(50, '03-1234-56789', 'First Periodic', 'Verified', 'System Default', '2022-05-28 05:27:57', 1),
(51, '03-1234-56789', 'Second Periodic', 'Verified', 'System Default', '2022-05-28 05:27:57', 1),
(52, '03-1234-56789', 'Second Periodic', 'Verified', 'System Default', '2022-05-28 05:27:58', 1),
(53, '03-1234-56789', 'Third Periodic', 'Verified', 'System Default', '2022-05-28 05:49:14', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activitylog`
--
ALTER TABLE `activitylog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adminuseraccount`
--
ALTER TABLE `adminuseraccount`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_id` (`userName`);

--
-- Indexes for table `admin_notification`
--
ALTER TABLE `admin_notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schoolyear_and_semester`
--
ALTER TABLE `schoolyear_and_semester`
  ADD PRIMARY KEY (`sy_id`);

--
-- Indexes for table `secretaryuseraccount`
--
ALTER TABLE `secretaryuseraccount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_form`
--
ALTER TABLE `student_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_notification`
--
ALTER TABLE `student_notification`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activitylog`
--
ALTER TABLE `activitylog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- AUTO_INCREMENT for table `adminuseraccount`
--
ALTER TABLE `adminuseraccount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `admin_notification`
--
ALTER TABLE `admin_notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `schoolyear_and_semester`
--
ALTER TABLE `schoolyear_and_semester`
  MODIFY `sy_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `secretaryuseraccount`
--
ALTER TABLE `secretaryuseraccount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student_form`
--
ALTER TABLE `student_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=191;

--
-- AUTO_INCREMENT for table `student_notification`
--
ALTER TABLE `student_notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
