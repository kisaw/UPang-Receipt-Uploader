<?php
include'../DATABASE/db_admin_connection.php';
include_once 'session_admin.php';


if (isset($_GET['approve']))
{
	$admin=$_SESSION['userName'];
	$id=$_GET['approve'];
	$paymentStatus=$_GET['paymentstatus'];
//STUDENT NOTIFICATION
	$fetchname= mysqli_query($adminconnection,"SELECT * FROM adminuseraccount WHERE userName ='$admin'");
	$name= mysqli_fetch_assoc($fetchname);
	$fullname =$name['firstName'].' '.$name['lastName'];
		$studentnotifquery = "SELECT * FROM student_form WHERE id='$id'";
			$studentnotifquery_run = mysqli_query($adminconnection, $studentnotifquery);
			$list = mysqli_fetch_assoc($studentnotifquery_run);
			$studentNumber= $list['student_id'];
			$feetype= $list['periodic'];
			$description= 'Verified';
		mysqli_query($adminconnection,"INSERT INTO student_notification (studentNumber,periodic,description,admin) VALUES('$studentNumber','$feetype','$description','$fullname')");
//STUDENT NOTIFICATION
	$fetchname= mysqli_query($adminconnection,"SELECT * FROM adminuseraccount WHERE userName ='$admin'");
	$name= mysqli_fetch_assoc($fetchname);
	$fullname =$name['firstName'].' '.$name['lastName'];
	if($paymentStatus == "full"){
		mysqli_query($adminconnection,"UPDATE student_form SET approval='approved',issuedBy='$fullname' WHERE id='$id'");
	}
	// if partial
	else{
		mysqli_query($adminconnection,"UPDATE student_form SET approval='semi-approved',issuedBy='$fullname' WHERE id='$id'");
	}
		echo "<script>alert('A record Verified successfully');</script>";
        echo "<script>document.location='request.php';</script>";
        ?>
        	<!--ACTIVITY LOGS-->
			<?php 
			$studentquery = "SELECT * FROM student_form WHERE id='$id'";
			$studentquery_run = mysqli_query($adminconnection, $studentquery);
			$row = mysqli_fetch_assoc($studentquery_run);
			$admin=$_SESSION['userName'];
			$firstname= $row['firstname'];
			$lastname= $row['lastname'];
			$student_id= $row['student_id'];
			$periodic= $row['periodic'];

			$action='Verified a student form [NAME: '.$firstname.' '.$lastname.' STUDENT NUMBER: '.$student_id.' PERIODIC: '.$periodic.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->
		
	<?php
}

if(isset($_GET['delete']))
{
	$id=$_GET['delete'];
	 ?>
			<!--ACTIVITY LOGS-->
			<?php 
			$studentquery = "SELECT * FROM student_form WHERE id='$id'";
			$studentquery_run = mysqli_query($adminconnection, $studentquery);
			$row = mysqli_fetch_assoc($studentquery_run);
			$admin=$_SESSION['userName'];
			$firstname= $row['firstname'];
			$lastname= $row['lastname'];
			$student_id= $row['student_id'];
			$periodic= $row['periodic'];

			$action='Deleted a form request [NAME: '.$firstname.' '.$lastname.' STUDENT NUMBER: '.$student_id.' PERIODIC: '.$periodic.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->
		
	<?php	
//STUDENT NOTIFICATION
	$fetchname= mysqli_query($adminconnection,"SELECT * FROM adminuseraccount WHERE userName ='$admin'");
	$name= mysqli_fetch_assoc($fetchname);
	$fullname =$name['firstName'].' '.$name['lastName'];	
		$studentnotifquery = "SELECT * FROM student_form WHERE id='$id'";
			$studentnotifquery_run = mysqli_query($adminconnection, $studentnotifquery);
			$list = mysqli_fetch_assoc($studentnotifquery_run);
			$studentNumber= $list['student_id'];
			$feetype= $list['periodic'];
			$description= 'Deleted';
		mysqli_query($adminconnection,"INSERT INTO student_notification (studentNumber,periodic,description,admin) VALUES('$studentNumber','$feetype','$description','$fullname')");
//STUDENT NOTIFICATION

		mysqli_query($adminconnection,"DELETE FROM student_form WHERE id='$id'");
		echo "<script>alert('A record deleted successfully');</script>";
        echo "<script>document.location='request.php';</script>";
          
}

 ?>