<?php include_once 'session_admin.php'?>
<?php include '../DATABASE/db_student_connection.php'?>
<?php include '../DATABASE/db_admin_connection.php'?>
<?php 
	if(isset($_POST['update'])){
		$id=$_GET['edit'];

		$firstName= $_POST['firstName'];
		$lastName= $_POST['lastName'];
		$studentNumber= $_POST['studentNumber'];
		$password= $_POST['password'];
		$email= $_POST['email'];
		$contact= $_POST['contact'];
		$course= $_POST['course'];

		
		$sql= mysqli_query($studentconnection, "UPDATE studentaccount SET firstName='$firstName', lastName='$lastName', studentNumber='$studentNumber', password='$password', email='$email', contact='$contact', course='$course' WHERE studentNumber='$id'");

		if($sql){
			echo "<script>alert('A form was updated successfully')</script>";
			echo "<script>document.location='student.php';</script>";
			?>
			 <!--ACTIVITY LOGS-->
			<?php 
			$studentquery = "SELECT * FROM studentaccount WHERE studentNumber='$id'";
			$studentquery_run = mysqli_query($studentconnection, $studentquery);
			$row = mysqli_fetch_assoc($studentquery_run);
			$admin=$_SESSION['userName'];
			$firstName= $row['firstName'];
			$lastName= $row['lastName'];
			$studentNumber= $row['studentNumber'];

			$action='Edited a user account [NAME: '.$firstName.' '.$lastName.' STUDENT NUMBER: '.$studentNumber.' COURSE: '.$course.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->
			<?php			
		}
		else{
			echo "<script>alert('Something went wrong!')</script>";
			echo "<script>document.location='edit_student_account.php';</script>";
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- AUTO LOGOUT-->
	<meta http-equiv="refresh" content="120;url=logout_admin.php"/>	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- BOOTSTRAP -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>

	<title>Edit Student Account</title>
	<!-- My CSS -->
	<style type="text/css">
.container{
 margin-top: 3rem;
 text-align: center;
 width: 50%;
}
h1{
	margin-bottom: 1em;
}
.form-control{
	margin-bottom: 1em;
}

.form-select{
	margin-bottom: 1em;
}	

label{
	float: left;
	font-weight: bold;
}
div .button{
	text-align: right;
	display: block;
}
</style>

</head>
<body>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>Edit Student Account</h1>
			</div>
		</div>

		<form method="POST">
			<?php 
				$id= $_GET['edit'];
				$sql= mysqli_query($studentconnection, "SELECT * FROM studentaccount WHERE studentNumber ='$id'");
					while ($row=mysqli_fetch_assoc($sql)){
			?>

			<div class="row">
				<div class="col-md-6">
					<label>First Name</label>
					<input type="text" name="firstName" value="<?php echo $row['firstName'];?>" class="form-control" placeholder="First Name" required>
				</div>	
				<div class="col-md-6">
					<label>Last Name</label>
					<input type="text" name="lastName" value="<?php echo $row['lastName'];?>" class="form-control" placeholder="Last Name" required>
				</div>	
			</div>

			<div class="row">
				<div class="col-md-12">
				<label>Student Number</label>
				<input type="text" name="studentNumber" value="<?php echo $row['studentNumber'];?>" class="form-control" placeholder="Student Number" required readOnly>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12">
				<label>Course</label>
					<select class="form-select" name="course" value ="<?php $row['course'];?>" required>
					  <option selected hidden ><?php echo $row['course'];?></option>
					  <option disabled style="font-weight: bold;">COLLEGE IF INFORMATION TECHNOLOGY</option>
					  <option value="Bachelor of Science in Information Technology">Bachelor of Science in Information Technology</option>
					  <option disabled style="font-weight: bold;">COLLEGE OF ENGINEERING AND ARCHITECTURE</option>
					  <option value="Bachelor of Science in Architecture">Bachelor of Science in Architecture</option>
					  <option value="Bachelor of Science in Civil Engineering">Bachelor of Science in Civil Engineering</option>
					  <option value="Bachelor of Science in Electrical Engineering">Bachelor of Science in Electrical Engineering</option>
					  <option value="Bachelor of Science in Electronics Engineering">Bachelor of Science in Electronics Engineering</option>
					  <option value="Bachelor of Science in Computer Engineering">Bachelor of Science in Computer Engineering</option>
						<option value="Bachelor of Science in Mechanical Engineering : PERMIT LEVEL">Bachelor of Science in Mechanical Engineering : PERMIT LEVEL</option>
					  <option disabled style="font-weight: bold;">COLLEGE OF SOCIAL SCIENCES</option>
					  <option value="Bachelor of Arts in Communication">Bachelor of Arts in Communication</option>
					  <option value="Bachelor of Arts in Political Science">Bachelor of Arts in Political Science</option>
					  <option value="Bachelor of Education">Bachelor of Education</option>
					  <option value="Bachelor of Education major in Pre-School Education">Bachelor of Education major in Pre-School Education</option>
					  <option value="Bachelor of Secondary Education major in Biological Science">Bachelor of Secondary Education major in Biological Science</option>
					  <option value="Bachelor of Secondary Education major in English">Bachelor of Secondary Education major in English</option>
					  <option value="Bachelor of Secondary Education major in Mathematics">Bachelor of Secondary Education major in Mathematics</option>
					  <option value="Bachelor of Science in Criminology">Bachelor of Science in Criminology</option>
					  <option disabled style="font-weight: bold;">COLLEGE OF MANAGEMENT AND ACCOUNTING</option>
					  <option value="Bachelor of Science in Accountancy">Bachelor of Science in Accountancy</option>
					  <option value="Bachelor of Science in Accounting Technology">Bachelor of Science in Accounting Technology</option>
					  <option value="Bachelor of Science in Business Administration major in Financial Management">Bachelor of Science in Business Administration major in Financial Management</option>
					  <option value="Bachelor of Science in Business Administration major in Marketing Management">Bachelor of Science in Business Administration major in Marketing Management</option>
					  <option value="Bachelor of Science in Hospitality Management">Bachelor of Science in Hospitality Management</option>
					  <option value="Bachelor of Science in Tourism Management">Bachelor of Science in Tourism Management</option>
					  <option disabled style="font-weight: bold;">COLLEGE OF HEALTH SCIENCES</option>
					  <option value="Bachelor of Science in Nursing">Bachelor of Science in Nursing</option>
					  <option value="Bachelor in Medical Laboratory Science">Bachelor in Medical Laboratory Science</option>
					  <option value="Bachelor of Science in Physical Therapy">Bachelor of Science in Physical Therapy</option>
					  <option value="Bachelor of Science in Pharmacy : PERMIT LEVEL">Bachelor of Science in Pharmacy : PERMIT LEVEL</option>
					  <option value="Diploma in Midwifery">Diploma in Midwifery</option>
					  <option value="Bachelor of Science in Midwifery">Bachelor of Science in Midwifery</option>
					</select>
			</div>

			</div>
			<div class="row">
				<div class="col-md-12">
				<label>Password</label>
				<input type="text" name="password" value="<?php echo $row['password'];?>" class="form-control" placeholder="Password" required>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12">
				<label>Email</label>
				<input type="text" name="email" value="<?php echo $row['email'];?>" class="form-control" placeholder="Email" required>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
				<label>Contact Number</label>
				<input type="text" name="contact" value="<?php echo $row['contact'];?>" class="form-control" placeholder="Contact" required>
				</div>

			<?php
				 }
			 ?>

			
			<div class="button">
			<a href="student.php" type="button" class="btn btn-secondary">BACK</a>
			<button type="text" name="update" class="btn btn-primary" onClick ="return confirm('Do you really want to update this account?');">UPDATE</button>
			</div>
		</form>
	</div>

</body>
</html>