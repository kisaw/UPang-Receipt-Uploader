<?php include_once 'session_admin.php'?>
<?php
include'../DATABASE/db_student_connection.php';
include '../DATABASE/db_admin_connection.php';


if(isset($_GET['delete']))
{
	$id=$_GET['delete'];
		?>
			 <!--ACTIVITY LOGS-->
			<?php 
			$studentquery = "SELECT * FROM studentaccount WHERE studentNumber='$id'";
			$studentquery_run = mysqli_query($studentconnection, $studentquery);
			$row = mysqli_fetch_assoc($studentquery_run);
			$admin=$_SESSION['userName'];
			$firstName= $row['firstName'];
			$lastName= $row['lastName'];
			$studentNumber= $row['studentNumber'];
			$course= $row['course'];

			$action='Deleted a user account [NAME: '.$firstName.' '.$lastName.' STUDENT NUMBER: '.$studentNumber.' COURSE: '.$course.']';
				$query= "INSERT INTO activitylog (admin,action) VALUES('$admin','$action')";
				$query_run = mysqli_query($adminconnection,$query);
			?>
			<!--ACTIVITY LOGS-->
	<?php
	mysqli_query($studentconnection,"DELETE FROM studentaccount WHERE studentNumber='$id'");
		echo "<script>alert('A student account deleted successfully');</script>";
        echo "<script>document.location='student.php';</script>";

}

 ?>